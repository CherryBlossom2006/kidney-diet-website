function recommendFood() {
    const choice = document.getElementById("diet").value;
    const resultDiv = document.getElementById("result");

    let foods = [];

    if (choice === "lowSodium") {
        foods = ["Fresh fruits", "Vegetables", "Rice", "Unsalted nuts"];
    } 
    else if (choice === "lowPotassium") {
        foods = ["Apples", "Berries", "Cabbage", "White bread"];
    } 
    else if (choice === "lowProtein") {
        foods = ["Rice", "Pasta", "Fruits", "Vegetables"];
    } 
    else {
        resultDiv.innerHTML = "<p>Please select a dietary need.</p>";
        return;
    }

    let html = "<h3>Recommended Foods:</h3><ul>";
    foods.forEach(food => {
        html += `<li>${food}</li>`;
    });
    html += "</ul>";

    resultDiv.innerHTML = html;
}